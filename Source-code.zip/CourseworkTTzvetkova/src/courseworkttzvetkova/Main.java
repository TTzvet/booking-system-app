package courseworkttzvetkova;

import courseworkttzvetkova.controllers.CustomerController;
import courseworkttzvetkova.controllers.FitnessClassController;
import courseworkttzvetkova.controllers.MonthlyReportsController;
import courseworkttzvetkova.controllers.StartMenuController;
import courseworkttzvetkova.fitnessClasses.FitnessClass;

import java.util.List;
import java.util.Scanner;


/**
 * The Class Main.
 *
 * @author Teodora.Tzvetkova
 */
public class Main {
	
	/** The m monthly reports controller. */
	static MonthlyReportsController mMonthlyReportsController = new MonthlyReportsController();
	
	/** The start menu controller. */
	static StartMenuController startMenuController = new StartMenuController();
	
	/** The fitness class controller. */
	static FitnessClassController fitnessClassController = new FitnessClassController();
	
	/** The customer controller. */
	static CustomerController customerController = new CustomerController();

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		InitialiseData initialiseData = new InitialiseData();
		List<Customer> customers = initialiseData.getCustomers();
		List<FitnessClass> fitnessClassList = initialiseData.getInitialData(customers);

		Scanner input = new Scanner(System.in);
		mainMenuController(input, fitnessClassList, customers);
	}

	/**
	 * Main menu controller.
	 *
	 * @param input the input
	 * @param fitnessClassList the fitness class list
	 * @param aCustomers the a customers
	 */
	public static void mainMenuController(Scanner input, List<FitnessClass> fitnessClassList,
			List<Customer> aCustomers) {
		char selectedOption = startMenuController.startMenu(input);

		if (selectedOption == 'e') {
			System.exit(0);
		} else if (selectedOption == 'a') {
			fitnessClassController.attendClass(input, fitnessClassList, aCustomers);
		} else if (selectedOption == 'c') {
			fitnessClassController.changeClass(input, fitnessClassList, aCustomers);
		} else if (selectedOption == 'n') {
			customerController.addNewCustomer(input, fitnessClassList, aCustomers);
		} else if (selectedOption == 'b') {
			fitnessClassController.bookClass(input, fitnessClassList, aCustomers);
		} else if (selectedOption == 'p') {
			mMonthlyReportsController.monthlyReportGeneral(input, fitnessClassList, aCustomers);
		} else if (selectedOption == 'r') {
			mMonthlyReportsController.monthlyReportIncome(input, fitnessClassList, aCustomers);
		}
		System.exit(0);
	}
}