
package courseworkttzvetkova;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;


/**
 * The Class FitnessSession.
 *
 * @author Teodora.Tzvetkova
 */
public class FitnessSession {
	
	/** The session start date time. */
	private LocalDateTime sessionStartDateTime;
	
	/** The session duration. */
	private Integer sessionDuration;
	
	/** The class name. */
	private String className;
	
	/** The booking list. */
	private List<Booking> bookingList = new ArrayList<>();

	
	/**
	 * Instantiates a new fitness session.
	 *
	 * @param aSessionStartDateTime the a session start date time
	 * @param aClassName the a class name
	 * @param aSessionDuration the a session duration
	 * @param aBookingList the a booking list
	 */
	public FitnessSession(LocalDateTime aSessionStartDateTime, String aClassName, Integer aSessionDuration,
			List<Booking> aBookingList) {
		sessionStartDateTime = aSessionStartDateTime;
		sessionDuration = aSessionDuration;
		bookingList = aBookingList;
		className = aClassName;
		for (Booking booking : bookingList) {
			booking.getCustomer().getFitnessSessionList().add(this);
		}
	}

	
	/**
	 * Gets the session start date time.
	 *
	 * @return the session start date time
	 */
	public LocalDateTime getSessionStartDateTime() {
		return sessionStartDateTime;
	}

	
	/**
	 * Sets the session start date time.
	 *
	 * @param aSessionStartDateTime the new session start date time
	 */
	public void setSessionStartDateTime(LocalDateTime aSessionStartDateTime) {
		sessionStartDateTime = aSessionStartDateTime;
	}

	
	/**
	 * Gets the booking list.
	 *
	 * @return the booking list
	 */
	public List<Booking> getBookingList() {
		return bookingList;
	}

	
	/**
	 * Sets the booking list.
	 *
	 * @param aBookingList the new booking list
	 */
	public void setBookingList(List<Booking> aBookingList) {
		bookingList = aBookingList;
	}

	
	/**
	 * Gets the session duration.
	 *
	 * @return the session duration
	 */
	public Integer getSessionDuration() {
		return sessionDuration;
	}

	
	/**
	 * Sets the session duration.
	 *
	 * @param aSessionDuration the new session duration
	 */
	public void setSessionDuration(Integer aSessionDuration) {
		sessionDuration = aSessionDuration;
	}

	
	/**
	 * Gets the class name.
	 *
	 * @return the class name
	 */
	public String getClassName() {
		return className;
	}

	
	/**
	 * Sets the class name.
	 *
	 * @param aClassName the new class name
	 */
	public void setClassName(String aClassName) {
		className = aClassName;
	}
}