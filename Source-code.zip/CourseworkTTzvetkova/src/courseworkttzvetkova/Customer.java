package courseworkttzvetkova;

import java.util.ArrayList;
import java.util.List;


/**
 * The Class Customer.
 *
 * @author Teodora.Tzvetkova
 */

public class Customer {
	
	/** The username. */
	private String username;
	
	/** The age. */
	private Integer age;
	
	/** The name. */
	private String name;
	
	/** The m fitness session list. */
	private List<FitnessSession> mFitnessSessionList = new ArrayList<>();

	
	/**
	 * Instantiates a new customer.
	 *
	 * @param username the username
	 * @param age the age
	 * @param name the name
	 */
	public Customer(String username, Integer age, String name) {
		this.username = username;
		this.age = age;
		this.name = name;
	}

	
	/**
	 * Gets the username.
	 *
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}

	
	/**
	 * Sets the username.
	 *
	 * @param aUsername the new username
	 */
	public void setUsername(String aUsername) {
		username = aUsername;
	}

	
	/**
	 * Gets the age.
	 *
	 * @return the age
	 */
	public Integer getAge() {
		return age;
	}

	
	/**
	 * Sets the age.
	 *
	 * @param aAge the new age
	 */
	public void setAge(Integer aAge) {
		age = aAge;
	}

	
	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	
	/**
	 * Sets the name.
	 *
	 * @param aName the new name
	 */
	public void setName(String aName) {
		name = aName;
	}

	
	/**
	 * Gets the fitness session list.
	 *
	 * @return the fitness session list
	 */
	public List<FitnessSession> getFitnessSessionList() {
		return mFitnessSessionList;
	}

	
	/**
	 * Sets the fitness session list.
	 *
	 * @param aFitnessSessionList the new fitness session list
	 */
	public void setFitnessSessionList(List<FitnessSession> aFitnessSessionList) {
		mFitnessSessionList = aFitnessSessionList;
	}
}