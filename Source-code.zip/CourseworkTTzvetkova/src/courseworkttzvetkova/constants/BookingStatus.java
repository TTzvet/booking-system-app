package courseworkttzvetkova.constants;


/**
 * The Class BookingStatus.
 *
 * @author Teodora.Tzvetkova
 */

public class BookingStatus {

	/** The Constant BOOKED. */
	public static final String BOOKED = "BOOKED";

	/** The Constant CHANGED. */
	public static final String CHANGED = "CHANGED";

	/** The Constant ATTENDED. */
	public static final String ATTENDED = "ATTENDED";

	/** The Constant CANCELLED. */
	public static final String CANCELLED = "CANCELLED";
}
