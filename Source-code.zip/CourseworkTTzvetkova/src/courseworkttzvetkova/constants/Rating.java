/*
 * 
 */
package courseworkttzvetkova.constants;


/**
 * The Class Rating.
 *
 * @author Teodora.Tzvetkova
 */

public class Rating {

	/** The Constant VERY_DISSATISFIED. */
	public static final Integer VERY_DISSATISFIED = 1;

	/** The Constant DISSATISFIED. */
	public static final Integer DISSATISFIED = 2;

	/** The Constant OK. */
	public static final Integer OK = 3;

	/** The Constant SATISFIED. */
	public static final Integer SATISFIED = 4;

	/** The Constant VERY_SATISFIED. */
	public static final Integer VERY_SATISFIED = 5;
}
