package courseworkttzvetkova;


/**
 * The Class Review.
 *
 * @author Teodora.Tzvetkova
 */

public class Review {
	
	/** The customer username. */
	private String customerUsername;
	
	/** The comment. */
	private String comment;
	
	/** The rating. */
	private Integer rating;

	
	/**
	 * Instantiates a new review.
	 *
	 * @param aCustomerUsername the a customer username
	 * @param aComment the a comment
	 * @param aRating the a rating
	 */
	public Review(String aCustomerUsername, String aComment, Integer aRating) {
		customerUsername = aCustomerUsername;
		comment = aComment;
		rating = aRating;
	}

	
	/**
	 * Gets the comment.
	 *
	 * @return the comment
	 */
	public String getComment() {
		return comment;
	}

	
	/**
	 * Sets the comment.
	 *
	 * @param aComment the new comment
	 */
	public void setComment(String aComment) {
		comment = aComment;
	}

	
	/**
	 * Gets the rating.
	 *
	 * @return the rating
	 */
	public Integer getRating() {
		return rating;
	}

	
	/**
	 * Sets the rating.
	 *
	 * @param aRating the new rating
	 */
	public void setRating(Integer aRating) {
		rating = aRating;
	}
}