package courseworkttzvetkova;

import courseworkttzvetkova.constants.BookingStatus;
import courseworkttzvetkova.constants.Rating;
import courseworkttzvetkova.fitnessClasses.FitnessClass;
import courseworkttzvetkova.fitnessClasses.IndoorCycling;
import courseworkttzvetkova.fitnessClasses.Pilates;
import courseworkttzvetkova.fitnessClasses.Spin;
import courseworkttzvetkova.fitnessClasses.Yoga;
import courseworkttzvetkova.fitnessClasses.Zumba;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;


/**
 * The Class InitialiseData.
 *
 * @author Teodora.Tzvetkova
 */

public class InitialiseData {

	/**
	 * Gets the customers. This method returns a list of customers.
	 *
	 * @return the customers
	 */
	public List<Customer> getCustomers() {
		List<Customer> customers = new ArrayList<>();
		/**
		 * 15 customers
		 */
		Customer customer1 = new Customer("jbloggs", 20, "Jo Bloggs");
		Customer customer2 = new Customer("gbennet", 23, "Gordon Bennett");
		Customer customer3 = new Customer("emdav", 32, "Emma Davidson");
		Customer customer4 = new Customer("cred", 35, "Clare Redhead");
		Customer customer5 = new Customer("mven", 19, "Michelle Ventre");
		Customer customer6 = new Customer("dmar", 32, "David Martin");
		Customer customer7 = new Customer("jchap", 55, "Joanne Chaplin");
		Customer customer8 = new Customer("dweb", 43, "Donna Webber");
		Customer customer9 = new Customer("dpear", 32, "Daniel Pearce");
		Customer customer10 = new Customer("kyat", 23, "Karen Yates");
		Customer customer11 = new Customer("cyat", 57, "Calvin Yates");
		Customer customer12 = new Customer("hgod", 54, "Heather Godbert");
		Customer customer13 = new Customer("mrob", 37, "Michelle Roberts");
		Customer customer14 = new Customer("mpear", 45, "Martin Pearce");
		Customer customer15 = new Customer("gpear", 29, "Georgia Pearce");
		customers.add(customer1);
		customers.add(customer2);
		customers.add(customer3);
		customers.add(customer4);
		customers.add(customer5);
		customers.add(customer6);
		customers.add(customer7);
		customers.add(customer8);
		customers.add(customer9);
		customers.add(customer10);
		customers.add(customer11);
		customers.add(customer12);
		customers.add(customer13);
		customers.add(customer14);
		customers.add(customer15);
		return customers;
	}

	/**
	 * Gets the initial data. This method returns a list of FitnessClass. 
	 * 
	 * @param aCustomers the a customers
	 * @return the initial data
	 */
	public List<FitnessClass> getInitialData(List<Customer> aCustomers) {
		List<Booking> bookings = getInitialBookings(aCustomers);
		List<Booking> indoorCyclingSessionBookings = new ArrayList<Booking>(bookings.subList(0, 4));
		List<Booking> pilatesSessionBookings = new ArrayList<Booking>(bookings.subList(4, 8));
		List<Booking> spinSessionBookings = new ArrayList<Booking>(bookings.subList(8, 12));
		List<Booking> yogaSessionBookings = new ArrayList<Booking>(bookings.subList(12, 16));
		List<Booking> zumbaSessionBookings = new ArrayList<Booking>(bookings.subList(16, 20));

		
		FitnessSession indoorCyclingSession1 = new FitnessSession(LocalDateTime.of(2018, 11, 3, 10, 0),
				"Indoor Cycling", 60, indoorCyclingSessionBookings);

		FitnessSession indoorCyclingSession2 = new FitnessSession(LocalDateTime.of(2018, 11, 10, 10, 0),
				"Indoor Cycling", 60, new ArrayList<>());

		FitnessSession indoorCyclingSession3 = new FitnessSession(LocalDateTime.of(2018, 11, 17, 10, 0),
				"Indoor Cycling", 60, new ArrayList<>());

		FitnessSession indoorCyclingSession4 = new FitnessSession(LocalDateTime.of(2018, 11, 24, 10, 0),
				"Indoor Cycling", 60, new ArrayList<>());

		FitnessSession indoorCyclingSession5 = new FitnessSession(LocalDateTime.of(2018, 12, 1, 10, 0),
				"Indoor Cycling", 60, new ArrayList<>());

		FitnessSession indoorCyclingSession6 = new FitnessSession(LocalDateTime.of(2018, 12, 8, 10, 0),
				"Indoor Cycling", 60, new ArrayList<>());

		FitnessSession indoorCyclingSession7 = new FitnessSession(LocalDateTime.of(2018, 12, 15, 10, 0),
				"Indoor Cycling", 60, new ArrayList<>());

		FitnessSession indoorCyclingSession8 = new FitnessSession(LocalDateTime.of(2018, 12, 22, 10, 0),
				"Indoor Cycling", 60, new ArrayList<>());

		FitnessSession indoorCyclingSession9 = new FitnessSession(LocalDateTime.of(2018, 12, 29, 10, 0),
				"Indoor Cycling", 60, new ArrayList<>());

		List<FitnessSession> indoorCyclingFitnessSessions = new ArrayList<>();
		indoorCyclingFitnessSessions.add(indoorCyclingSession1);
		indoorCyclingFitnessSessions.add(indoorCyclingSession2);
		indoorCyclingFitnessSessions.add(indoorCyclingSession3);
		indoorCyclingFitnessSessions.add(indoorCyclingSession4);
		indoorCyclingFitnessSessions.add(indoorCyclingSession5);
		indoorCyclingFitnessSessions.add(indoorCyclingSession6);
		indoorCyclingFitnessSessions.add(indoorCyclingSession7);
		indoorCyclingFitnessSessions.add(indoorCyclingSession8);
		indoorCyclingFitnessSessions.add(indoorCyclingSession9);

		
		FitnessSession pilatesSession1 = new FitnessSession(LocalDateTime.of(2018, 11, 3, 19, 0), "Pilates", 60,
				pilatesSessionBookings);

		FitnessSession pilatesSession2 = new FitnessSession(LocalDateTime.of(2018, 11, 4, 19, 0), "Pilates", 60,
				new ArrayList<>());

		FitnessSession pilatesSession3 = new FitnessSession(LocalDateTime.of(2018, 11, 10, 19, 0), "Pilates", 60,
				new ArrayList<>());

		FitnessSession pilatesSession4 = new FitnessSession(LocalDateTime.of(2018, 11, 11, 19, 0), "Pilates", 60,
				new ArrayList<>());

		FitnessSession pilatesSession5 = new FitnessSession(LocalDateTime.of(2018, 11, 17, 19, 0), "Pilates", 60,
				new ArrayList<>());

		FitnessSession pilatesSession6 = new FitnessSession(LocalDateTime.of(2018, 11, 18, 19, 0), "Pilates", 60,
				new ArrayList<>());

		FitnessSession pilatesSession7 = new FitnessSession(LocalDateTime.of(2018, 11, 24, 19, 0), "Pilates", 60,
				new ArrayList<>());

		FitnessSession pilatesSession8 = new FitnessSession(LocalDateTime.of(2018, 11, 25, 19, 0), "Pilates", 60,
				new ArrayList<>());

		FitnessSession pilatesSession9 = new FitnessSession(LocalDateTime.of(2018, 12, 1, 19, 0), "Pilates", 60,
				new ArrayList<>());

		FitnessSession pilatesSession10 = new FitnessSession(LocalDateTime.of(2018, 12, 2, 19, 0), "Pilates", 60,
				new ArrayList<>());

		FitnessSession pilatesSession11 = new FitnessSession(LocalDateTime.of(2018, 12, 8, 19, 0), "Pilates", 60,
				new ArrayList<>());

		FitnessSession pilatesSession12 = new FitnessSession(LocalDateTime.of(2018, 12, 9, 19, 0), "Pilates", 60,
				new ArrayList<>());

		FitnessSession pilatesSession13 = new FitnessSession(LocalDateTime.of(2018, 12, 15, 19, 0), "Pilates", 60,
				new ArrayList<>());

		FitnessSession pilatesSession14 = new FitnessSession(LocalDateTime.of(2018, 12, 16, 19, 0), "Pilates", 60,
				new ArrayList<>());

		FitnessSession pilatesSession15 = new FitnessSession(LocalDateTime.of(2018, 12, 22, 19, 0), "Pilates", 60,
				new ArrayList<>());

		FitnessSession pilatesSession16 = new FitnessSession(LocalDateTime.of(2018, 12, 23, 19, 0), "Pilates", 60,
				new ArrayList<>());

		FitnessSession pilatesSession17 = new FitnessSession(LocalDateTime.of(2018, 12, 29, 19, 0), "Pilates", 60,
				new ArrayList<>());

		FitnessSession pilatesSession18 = new FitnessSession(LocalDateTime.of(2018, 12, 30, 19, 0), "Pilates", 60,
				new ArrayList<>());

		List<FitnessSession> pilatesFitnessSessions = new ArrayList<>();
		pilatesFitnessSessions.add(pilatesSession1);
		pilatesFitnessSessions.add(pilatesSession2);
		pilatesFitnessSessions.add(pilatesSession3);
		pilatesFitnessSessions.add(pilatesSession4);
		pilatesFitnessSessions.add(pilatesSession5);
		pilatesFitnessSessions.add(pilatesSession6);
		pilatesFitnessSessions.add(pilatesSession7);
		pilatesFitnessSessions.add(pilatesSession8);
		pilatesFitnessSessions.add(pilatesSession9);
		pilatesFitnessSessions.add(pilatesSession10);
		pilatesFitnessSessions.add(pilatesSession11);
		pilatesFitnessSessions.add(pilatesSession12);
		pilatesFitnessSessions.add(pilatesSession13);
		pilatesFitnessSessions.add(pilatesSession14);
		pilatesFitnessSessions.add(pilatesSession15);
		pilatesFitnessSessions.add(pilatesSession16);
		pilatesFitnessSessions.add(pilatesSession17);
		pilatesFitnessSessions.add(pilatesSession18);

		
		FitnessSession spinSession1 = new FitnessSession(LocalDateTime.of(2018, 11, 4, 10, 0), "Spin", 60,
				spinSessionBookings);

		FitnessSession spinSession2 = new FitnessSession(LocalDateTime.of(2018, 11, 11, 10, 0), "Spin", 60,
				new ArrayList<>());

		FitnessSession spinSession3 = new FitnessSession(LocalDateTime.of(2018, 11, 18, 10, 0), "Spin", 60,
				new ArrayList<>());

		FitnessSession spinSession4 = new FitnessSession(LocalDateTime.of(2018, 11, 25, 10, 0), "Spin", 60,
				new ArrayList<>());

		FitnessSession spinSession5 = new FitnessSession(LocalDateTime.of(2018, 12, 2, 10, 0), "Spin", 60,
				new ArrayList<>());

		FitnessSession spinSession6 = new FitnessSession(LocalDateTime.of(2018, 12, 9, 10, 0), "Spin", 60,
				new ArrayList<>());

		FitnessSession spinSession7 = new FitnessSession(LocalDateTime.of(2018, 12, 16, 10, 0), "Spin", 60,
				new ArrayList<>());

		FitnessSession spinSession8 = new FitnessSession(LocalDateTime.of(2018, 12, 23, 10, 0), "Spin", 60,
				new ArrayList<>());

		FitnessSession spinSession9 = new FitnessSession(LocalDateTime.of(2018, 12, 30, 10, 0), "Spin", 60,
				new ArrayList<>());

		List<FitnessSession> spinFitnessSessions = new ArrayList<>();
		spinFitnessSessions.add(spinSession1);
		spinFitnessSessions.add(spinSession2);
		spinFitnessSessions.add(spinSession3);
		spinFitnessSessions.add(spinSession4);
		spinFitnessSessions.add(spinSession5);
		spinFitnessSessions.add(spinSession6);
		spinFitnessSessions.add(spinSession7);
		spinFitnessSessions.add(spinSession8);
		spinFitnessSessions.add(spinSession9);

		
		FitnessSession yogaSession1 = new FitnessSession(LocalDateTime.of(2018, 11, 3, 17, 0), "Yoga", 60,
				yogaSessionBookings);

		FitnessSession yogaSession2 = new FitnessSession(LocalDateTime.of(2018, 11, 4, 17, 0), "Yoga", 60,
				new ArrayList<>());

		FitnessSession yogaSession3 = new FitnessSession(LocalDateTime.of(2018, 11, 10, 17, 0), "Yoga", 60,
				new ArrayList<>());

		FitnessSession yogaSession4 = new FitnessSession(LocalDateTime.of(2018, 11, 11, 17, 0), "Yoga", 60,
				new ArrayList<>());

		FitnessSession yogaSession5 = new FitnessSession(LocalDateTime.of(2018, 11, 17, 17, 0), "Yoga", 60,
				new ArrayList<>());

		FitnessSession yogaSession6 = new FitnessSession(LocalDateTime.of(2018, 11, 18, 17, 0), "Yoga", 60,
				new ArrayList<>());

		FitnessSession yogaSession7 = new FitnessSession(LocalDateTime.of(2018, 11, 24, 17, 0), "Yoga", 60,
				new ArrayList<>());

		FitnessSession yogaSession8 = new FitnessSession(LocalDateTime.of(2018, 11, 25, 17, 0), "Yoga", 60,
				new ArrayList<>());

		FitnessSession yogaSession9 = new FitnessSession(LocalDateTime.of(2018, 12, 1, 17, 0), "Yoga", 60,
				new ArrayList<>());

		FitnessSession yogaSession10 = new FitnessSession(LocalDateTime.of(2018, 12, 2, 17, 0), "Yoga", 60,
				new ArrayList<>());

		FitnessSession yogaSession11 = new FitnessSession(LocalDateTime.of(2018, 12, 8, 17, 0), "Yoga", 60,
				new ArrayList<>());

		FitnessSession yogaSession12 = new FitnessSession(LocalDateTime.of(2018, 12, 9, 17, 0), "Yoga", 60,
				new ArrayList<>());

		FitnessSession yogaSession13 = new FitnessSession(LocalDateTime.of(2018, 12, 15, 17, 0), "Yoga", 60,
				new ArrayList<>());

		FitnessSession yogaSession14 = new FitnessSession(LocalDateTime.of(2018, 12, 16, 17, 0), "Yoga", 60,
				new ArrayList<>());

		FitnessSession yogaSession15 = new FitnessSession(LocalDateTime.of(2018, 12, 22, 17, 0), "Yoga", 60,
				new ArrayList<>());

		FitnessSession yogaSession16 = new FitnessSession(LocalDateTime.of(2018, 12, 23, 17, 0), "Yoga", 60,
				new ArrayList<>());

		FitnessSession yogaSession17 = new FitnessSession(LocalDateTime.of(2018, 12, 29, 17, 0), "Yoga", 60,
				new ArrayList<>());

		FitnessSession yogaSession18 = new FitnessSession(LocalDateTime.of(2018, 12, 30, 17, 0), "Yoga", 60,
				new ArrayList<>());

		List<FitnessSession> yogaFitnessSessions = new ArrayList<>();
		yogaFitnessSessions.add(yogaSession1);
		yogaFitnessSessions.add(yogaSession2);
		yogaFitnessSessions.add(yogaSession3);
		yogaFitnessSessions.add(yogaSession4);
		yogaFitnessSessions.add(yogaSession5);
		yogaFitnessSessions.add(yogaSession6);
		yogaFitnessSessions.add(yogaSession7);
		yogaFitnessSessions.add(yogaSession8);
		yogaFitnessSessions.add(yogaSession9);
		yogaFitnessSessions.add(yogaSession10);
		yogaFitnessSessions.add(yogaSession11);
		yogaFitnessSessions.add(yogaSession12);
		yogaFitnessSessions.add(yogaSession13);
		yogaFitnessSessions.add(yogaSession14);
		yogaFitnessSessions.add(yogaSession15);
		yogaFitnessSessions.add(yogaSession16);
		yogaFitnessSessions.add(yogaSession17);
		yogaFitnessSessions.add(yogaSession18);

		
		FitnessSession zumbaSession1 = new FitnessSession(LocalDateTime.of(2018, 11, 3, 14, 0), "Zumba", 60,
				zumbaSessionBookings);

		FitnessSession zumbaSession2 = new FitnessSession(LocalDateTime.of(2018, 11, 4, 14, 0), "Zumba", 60,
				new ArrayList<>());

		FitnessSession zumbaSession3 = new FitnessSession(LocalDateTime.of(2018, 11, 10, 14, 0), "Zumba", 60,
				new ArrayList<>());

		FitnessSession zumbaSession4 = new FitnessSession(LocalDateTime.of(2018, 11, 11, 14, 0), "Zumba", 60,
				new ArrayList<>());

		FitnessSession zumbaSession5 = new FitnessSession(LocalDateTime.of(2018, 11, 17, 14, 0), "Zumba", 60,
				new ArrayList<>());

		FitnessSession zumbaSession6 = new FitnessSession(LocalDateTime.of(2018, 11, 18, 14, 0), "Zumba", 60,
				new ArrayList<>());

		FitnessSession zumbaSession7 = new FitnessSession(LocalDateTime.of(2018, 11, 24, 14, 0), "Zumba", 60,
				new ArrayList<>());

		FitnessSession zumbaSession8 = new FitnessSession(LocalDateTime.of(2018, 11, 25, 14, 0), "Zumba", 60,
				new ArrayList<>());

		FitnessSession zumbaSession9 = new FitnessSession(LocalDateTime.of(2018, 12, 1, 14, 0), "Zumba", 60,
				new ArrayList<>());

		FitnessSession zumbaSession10 = new FitnessSession(LocalDateTime.of(2018, 12, 2, 14, 0), "Zumba", 60,
				new ArrayList<>());

		FitnessSession zumbaSession11 = new FitnessSession(LocalDateTime.of(2018, 12, 8, 14, 0), "Zumba", 60,
				new ArrayList<>());

		FitnessSession zumbaSession12 = new FitnessSession(LocalDateTime.of(2018, 12, 9, 14, 0), "Zumba", 60,
				new ArrayList<>());

		FitnessSession zumbaSession13 = new FitnessSession(LocalDateTime.of(2018, 12, 15, 14, 0), "Zumba", 60,
				new ArrayList<>());

		FitnessSession zumbaSession14 = new FitnessSession(LocalDateTime.of(2018, 12, 16, 14, 0), "Zumba", 60,
				new ArrayList<>());

		FitnessSession zumbaSession15 = new FitnessSession(LocalDateTime.of(2018, 12, 22, 14, 0), "Zumba", 60,
				new ArrayList<>());

		FitnessSession zumbaSession16 = new FitnessSession(LocalDateTime.of(2018, 12, 23, 14, 0), "Zumba", 60,
				new ArrayList<>());

		FitnessSession zumbaSession17 = new FitnessSession(LocalDateTime.of(2018, 12, 29, 14, 0), "Zumba", 60,
				new ArrayList<>());

		FitnessSession zumbaSession18 = new FitnessSession(LocalDateTime.of(2018, 12, 30, 14, 0), "Zumba", 60,
				new ArrayList<>());

		List<FitnessSession> zumbaFitnessSessions = new ArrayList<>();
		zumbaFitnessSessions.add(zumbaSession1);
		zumbaFitnessSessions.add(zumbaSession2);
		zumbaFitnessSessions.add(zumbaSession3);
		zumbaFitnessSessions.add(zumbaSession4);
		zumbaFitnessSessions.add(zumbaSession5);
		zumbaFitnessSessions.add(zumbaSession6);
		zumbaFitnessSessions.add(zumbaSession7);
		zumbaFitnessSessions.add(zumbaSession8);
		zumbaFitnessSessions.add(zumbaSession9);
		zumbaFitnessSessions.add(zumbaSession10);
		zumbaFitnessSessions.add(zumbaSession11);
		zumbaFitnessSessions.add(zumbaSession12);
		zumbaFitnessSessions.add(zumbaSession13);
		zumbaFitnessSessions.add(zumbaSession14);
		zumbaFitnessSessions.add(zumbaSession15);
		zumbaFitnessSessions.add(zumbaSession16);
		zumbaFitnessSessions.add(zumbaSession17);
		zumbaFitnessSessions.add(zumbaSession18);

		/**
		 * Creates the fitness classes and assigns the sessions contained in the fitness classes.
		 */
		FitnessClass indoorCyclingFitnessClass = new IndoorCycling(indoorCyclingFitnessSessions);
		FitnessClass pilatesFitnessClass = new Pilates(pilatesFitnessSessions);
		FitnessClass spinFitnessClass = new Spin(spinFitnessSessions);
		FitnessClass yogaFitnessClass = new Yoga(yogaFitnessSessions);
		FitnessClass zumbaFitnessClass = new Zumba(zumbaFitnessSessions);
		
		/**
		 * Adds all classes into an ArrayList and returns the fitnessClassList.
		 */
		
		List<FitnessClass> fitnessClassList = new ArrayList<>();
		fitnessClassList.add(indoorCyclingFitnessClass);
		fitnessClassList.add(pilatesFitnessClass);
		fitnessClassList.add(spinFitnessClass);
		fitnessClassList.add(yogaFitnessClass);
		fitnessClassList.add(zumbaFitnessClass);
		return fitnessClassList;
	}

	/**
	 * Gets the initial bookings. This method returns a list of bookings.
	 *
	 * @param customers the customers
	 * @return the initial bookings
	 */
	private List<Booking> getInitialBookings(List<Customer> customers) {
		List<Booking> bookings = new ArrayList<>();

		/**
		 * 20 reviews
		 */
		Review review1 = new Review(customers.get(0).getUsername(), "Very happy", Rating.VERY_SATISFIED);
		Review review2 = new Review(customers.get(1).getUsername(), "Could be better", Rating.SATISFIED);
		Review review3 = new Review(customers.get(2).getUsername(), "I enjoyed it", Rating.SATISFIED);
		Review review4 = new Review(customers.get(3).getUsername(), "very good", Rating.SATISFIED);
		Review review5 = new Review(customers.get(4).getUsername(), "A bit disappointed", Rating.DISSATISFIED);
		Review review6 = new Review(customers.get(5).getUsername(), "I expected a bit more", Rating.OK);
		Review review7 = new Review(customers.get(6).getUsername(), "Too difficult for me", Rating.DISSATISFIED);
		Review review8 = new Review(customers.get(7).getUsername(), "Good overall", Rating.SATISFIED);
		Review review9 = new Review(customers.get(8).getUsername(), "I didn't expect to like it so much",
				Rating.SATISFIED);
		Review review10 = new Review(customers.get(9).getUsername(), "It was perfect", Rating.VERY_SATISFIED);
		Review review11 = new Review(customers.get(10).getUsername(), "Could be improved", Rating.OK);
		Review review12 = new Review(customers.get(11).getUsername(), "Happy overall", Rating.SATISFIED);
		Review review13 = new Review(customers.get(12).getUsername(), "It was good, but not for me", Rating.OK);
		Review review14 = new Review(customers.get(13).getUsername(), "I liked it and I will try other classes too",
				Rating.SATISFIED);
		Review review15 = new Review(customers.get(14).getUsername(), "Exceeded my expectations",
				Rating.VERY_SATISFIED);
		Review review16 = new Review(customers.get(0).getUsername(), "It was brilliant, I will definitely book again",
				Rating.VERY_SATISFIED);
		Review review17 = new Review(customers.get(1).getUsername(), "Very pleased with it, will definitely come again",
				Rating.VERY_SATISFIED);
		Review review18 = new Review(customers.get(2).getUsername(), "I enjoyed the class and the activities",
				Rating.SATISFIED);
		Review review19 = new Review(customers.get(3).getUsername(), "It was OK, but could be better", Rating.OK);
		Review review20 = new Review(customers.get(4).getUsername(), "The best class I have even been to",
				Rating.VERY_SATISFIED);

		/**
		 * 20 bookings
		 */
		bookings.add(new Booking(customers.get(0), review1, BookingStatus.ATTENDED));
		bookings.add(new Booking(customers.get(1), review2, BookingStatus.ATTENDED));
		bookings.add(new Booking(customers.get(2), review3, BookingStatus.ATTENDED));
		bookings.add(new Booking(customers.get(3), review4, BookingStatus.ATTENDED));
		bookings.add(new Booking(customers.get(4), review5, BookingStatus.ATTENDED));
		bookings.add(new Booking(customers.get(5), review6, BookingStatus.ATTENDED));
		bookings.add(new Booking(customers.get(6), review7, BookingStatus.ATTENDED));
		bookings.add(new Booking(customers.get(7), review8, BookingStatus.ATTENDED));
		bookings.add(new Booking(customers.get(8), review9, BookingStatus.ATTENDED));
		bookings.add(new Booking(customers.get(9), review10, BookingStatus.ATTENDED));
		bookings.add(new Booking(customers.get(10), review11, BookingStatus.ATTENDED));
		bookings.add(new Booking(customers.get(11), review12, BookingStatus.ATTENDED));
		bookings.add(new Booking(customers.get(12), review13, BookingStatus.ATTENDED));
		bookings.add(new Booking(customers.get(13), review14, BookingStatus.ATTENDED));
		bookings.add(new Booking(customers.get(14), review15, BookingStatus.ATTENDED));
		bookings.add(new Booking(customers.get(0), review16, BookingStatus.ATTENDED));
		bookings.add(new Booking(customers.get(1), review17, BookingStatus.ATTENDED));
		bookings.add(new Booking(customers.get(2), review18, BookingStatus.ATTENDED));
		bookings.add(new Booking(customers.get(3), review19, BookingStatus.ATTENDED));
		bookings.add(new Booking(customers.get(4), review20, BookingStatus.ATTENDED));

		return bookings;
	}
}
