package courseworkttzvetkova.fitnessClasses;

import courseworkttzvetkova.FitnessSession;
import java.util.ArrayList;
import java.util.List;


/**
 * The Class Yoga.
 *
 * @author Teodora.Tzvetkova
 */

public class Yoga implements FitnessClass {
	
	/** The sessions. */
	private List<FitnessSession> sessions = new ArrayList<>();

	/**
	 * Instantiates a new yoga.
	 *
	 * @param aSessions the a sessions
	 */
	public Yoga(List<FitnessSession> aSessions) {
		sessions = aSessions;
	}

	
	@Override
	public String getName() {
		return "Yoga";
	}

	
	@Override
	public String getInstructor() {
		return "Mrs. Jameson";
	}

	
	@Override
	public Integer getPrice() {
		return 8;
	}

	
	@Override
	public List<FitnessSession> getFitnessSessions() {
		return sessions;
	}
}
