package courseworkttzvetkova.fitnessClasses;

import courseworkttzvetkova.FitnessSession;

import java.util.ArrayList;
import java.util.List;


/**
 * The Class Zumba.
 *
 * @author Teodora.Tzvetkova
 */

public class Zumba implements FitnessClass {
	
	/** The sessions. */
	private List<FitnessSession> sessions = new ArrayList<>();

	/**
	 * Instantiates a new zumba.
	 *
	 * @param aSessions the a sessions
	 */
	public Zumba(List<FitnessSession> aSessions) {
		sessions = aSessions;
	}

	
	@Override
	public String getName() {
		return "Zumba";
	}

	
	@Override
	public String getInstructor() {
		return "Mr. Smith";
	}

	
	@Override
	public Integer getPrice() {
		return 10;
	}

	
	@Override
	public List<FitnessSession> getFitnessSessions() {
		return sessions;
	}
}