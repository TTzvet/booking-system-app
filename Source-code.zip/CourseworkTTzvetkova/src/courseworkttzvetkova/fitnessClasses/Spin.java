package courseworkttzvetkova.fitnessClasses;

import courseworkttzvetkova.FitnessSession;

import java.util.ArrayList;
import java.util.List;


/**
 * The Class Spin.
 *
 * @author Teodora.Tzvetkova
 */

public class Spin implements FitnessClass {
	
	/** The sessions. */
	private List<FitnessSession> sessions = new ArrayList<>();

	/**
	 * Instantiates a new spin.
	 *
	 * @param aSessions the a sessions
	 */
	public Spin(List<FitnessSession> aSessions) {
		sessions = aSessions;
	}

	
	@Override
	public String getName() {
		return "Spin";
	}

	
	@Override
	public String getInstructor() {
		return "Mrs. Peters";
	}

	
	@Override
	public Integer getPrice() {
		return 12;
	}

	
	@Override
	public List<FitnessSession> getFitnessSessions() {
		return sessions;
	}
}
