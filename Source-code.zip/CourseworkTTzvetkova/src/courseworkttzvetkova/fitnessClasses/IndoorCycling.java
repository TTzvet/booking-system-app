package courseworkttzvetkova.fitnessClasses;

import courseworkttzvetkova.FitnessSession;
import java.util.ArrayList;
import java.util.List;


/**
 * The Class IndoorCycling.
 *
 * @author Teodora.Tzvetkova
 */

public class IndoorCycling implements FitnessClass {
	
	/** The sessions. */
	private List<FitnessSession> sessions = new ArrayList<>();

	/**
	 * Instantiates a new indoor cycling.
	 *
	 * @param aSessions the a sessions
	 */
	public IndoorCycling(List<FitnessSession> aSessions) {
		sessions = aSessions;
	}

	
	@Override
	public String getName() {
		return "Indoor Cycling";
	}

	
	@Override
	public String getInstructor() {
		return "Mr. Johnsons";
	}

	
	@Override
	public Integer getPrice() {
		return 15;
	}

	
	@Override
	public List<FitnessSession> getFitnessSessions() {
		return sessions;
	}
}