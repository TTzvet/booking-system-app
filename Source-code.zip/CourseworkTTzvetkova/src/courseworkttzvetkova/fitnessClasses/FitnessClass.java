package courseworkttzvetkova.fitnessClasses;

import courseworkttzvetkova.FitnessSession;

import java.util.List;


/**
 * The Interface FitnessClass.
 *
 * @author Teodora.Tzvetkova
 */
public interface FitnessClass {

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	String getName();

	/**
	 * Gets the instructor.
	 *
	 * @return the instructor
	 */
	String getInstructor();

	/**
	 * Gets the price.
	 *
	 * @return the price
	 */
	Integer getPrice();

	/**
	 * Gets the fitness sessions.
	 *
	 * @return the fitness sessions
	 */
	List<FitnessSession> getFitnessSessions();
}
