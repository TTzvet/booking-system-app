package courseworkttzvetkova.fitnessClasses;

import courseworkttzvetkova.FitnessSession;

import java.util.ArrayList;
import java.util.List;


/**
 * The Class Pilates.
 *
 * @author Teodora.Tzvetkova
 */

public class Pilates implements FitnessClass {
	
	/** The sessions. */
	private List<FitnessSession> sessions = new ArrayList<>();

	/**
	 * Instantiates a new pilates.
	 *
	 * @param aSessions the a sessions
	 */
	public Pilates(List<FitnessSession> aSessions) {
		sessions = aSessions;
	}

	
	@Override
	public String getName() {
		return "Pilates";
	}

	
	@Override
	public String getInstructor() {
		return "Mr Jacob";
	}

	
	@Override
	public Integer getPrice() {
		return 6;
	}

	
	@Override
	public List<FitnessSession> getFitnessSessions() {
		return sessions;
	}
}