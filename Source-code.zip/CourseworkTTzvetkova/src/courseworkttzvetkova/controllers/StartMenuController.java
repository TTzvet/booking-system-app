package courseworkttzvetkova.controllers;

import java.util.Scanner;


/**
 * The Class StartMenuController.
 *
 * @author Teodora.Tzvetkova
 */

public class StartMenuController {

	/**
	 * Start menu.
	 *
	 * @param input the input
	 * @return the char
	 */
	public char startMenu(Scanner input) {
		System.out.println("Please select from the following options: ");
		System.out.println("Add new customer (enter n)");
		System.out.println("Book Fitness class (enter b)");
		System.out.println("Change Fitness Class (enter c)");
		System.out.println("Attend Fitness Class (enter a)");
		System.out.println("Produce monthly report (enter p)");
		System.out.println("Produce monthly report for highest income per class (enter r)");
		System.out.println("Enter e for exit");
		return input.next().charAt(0);
	}
}