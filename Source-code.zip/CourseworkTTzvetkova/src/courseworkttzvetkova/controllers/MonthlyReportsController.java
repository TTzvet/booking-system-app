package courseworkttzvetkova.controllers;

import courseworkttzvetkova.Booking;
import courseworkttzvetkova.Customer;
import courseworkttzvetkova.FitnessSession;
import courseworkttzvetkova.Main;
import courseworkttzvetkova.constants.BookingStatus;
import courseworkttzvetkova.fitnessClasses.FitnessClass;

import java.util.*;


/**
 * The Class MonthlyReportsController.
 *
 * @author Teodora.Tzvetkova
 */

public class MonthlyReportsController {
	
	/** The start menu controller. */
	static StartMenuController startMenuController = new StartMenuController();

	/**
	 * Monthly report general.
	 *
	 * @param input the input
	 * @param fitnessClassList the fitness class list
	 * @param aCustomers the a customers
	 */
	public void monthlyReportGeneral(Scanner input, List<FitnessClass> fitnessClassList, List<Customer> aCustomers) {
		int monthInt = getMonthInt(input, fitnessClassList, aCustomers);
		
		/**
		 * precondition: 1 <= monthNumber <= 12 
		 */
		
		if (monthInt >= 1 && monthInt <= 12) {
			outputMonthlyReport(monthInt, fitnessClassList);
			endFlow(input, fitnessClassList, aCustomers);
		} else {
			System.out.println("invalid input. Please try again.");
			monthlyReportGeneral(input, fitnessClassList, aCustomers);
		}
	}

	/**
	 * Monthly report income.
	 *
	 * @param input the input
	 * @param fitnessClassList the fitness class list
	 * @param aCustomers the a customers
	 */
	public void monthlyReportIncome(Scanner input, List<FitnessClass> fitnessClassList, List<Customer> aCustomers) {
		int monthInt = getMonthInt(input, fitnessClassList, aCustomers);
		if (monthInt >= 1 && monthInt <= 12) {
			outputMonthlyReportIncome(monthInt, fitnessClassList);
			endFlow(input, fitnessClassList, aCustomers);
		} else {
			System.out.println("invalid input. Please try again.");
			monthlyReportIncome(input, fitnessClassList, aCustomers);
		}
	}

	/**
	 * Output monthly report income.
	 *
	 * @param aMonthInt the a month int
	 * @param aFitnessClassList the a fitness class list
	 */
	private void outputMonthlyReportIncome(int aMonthInt, List<FitnessClass> aFitnessClassList) {
		Map<Integer, String> incomePerClass = new HashMap<>();
		for (FitnessClass fitnessClass : aFitnessClassList) {
			int totalIncomePerClass = 0;
			for (FitnessSession fitnessSession : fitnessClass.getFitnessSessions()) {
				if (fitnessSession.getSessionStartDateTime().getMonthValue() == aMonthInt) {
					for (Booking booking : fitnessSession.getBookingList()) {
						if (!booking.getBookingStatus().equals(BookingStatus.CANCELLED)) {
							totalIncomePerClass += fitnessClass.getPrice();
						}
					}
				}
			}
			incomePerClass.put(totalIncomePerClass, fitnessClass.getName());
		}
		ArrayList<Integer> incomes = new ArrayList<>();
		incomes.addAll(incomePerClass.keySet());
		int maxIncome = getMax(incomes);
		if (maxIncome == 0) {
			System.out.println("No income from any of the classes in this month");
		} else {
			String className = incomePerClass.get(maxIncome);
			System.out.println("Highest income class: " + className + "; amount: " + maxIncome);
		}
	}

	/**
	 * Gets the max.
	 *
	 * @param list the list
	 * @return the max
	 */
	private int getMax(List<Integer> list) {
		int max = 0;
		for (int i = 0; i < list.size(); i++) {
			if (list.get(i) > max) {
				max = list.get(i);
			}
		}
		return max;
	}

	/**
	 * Gets the month int.
	 *
	 * @param input the input
	 * @param fitnessClassList the fitness class list
	 * @param aCustomers the a customers
	 * @return the month int
	 */
	private int getMonthInt(Scanner input, List<FitnessClass> fitnessClassList, List<Customer> aCustomers) {
		System.out.println("Please enter the month you want to produce the report for in numeric form (e.g 1,2,10)");
		String month = input.next();
		int monthInt = 0;

		/**
		 * Use try/catch to validate the user's input which needs to be numeric. 
		 */
		
		try {
			monthInt = Integer.parseInt(month);
		}
		catch (Exception ae) {
			System.out.println("invalid input. Please try again.");
			monthlyReportGeneral(input, fitnessClassList, aCustomers);
		}
		return monthInt;
	}

	/**
	 * Output monthly report.
	 *
	 * @param monthInt the month int
	 * @param fitnessClassList the fitness class list
	 */
	private void outputMonthlyReport(int monthInt, List<FitnessClass> fitnessClassList) {
		for (FitnessClass fitnessClass : fitnessClassList) {
			Integer averageRatingSum = 0;
			int totalCustomersAttended = 0;
			int totalCustomersBooked = 0;
			for (FitnessSession fitnessSession : fitnessClass.getFitnessSessions()) {
				if (fitnessSession.getSessionStartDateTime().getMonthValue() == monthInt) {
					for (Booking booking : fitnessSession.getBookingList()) {
						if (booking.getBookingStatus().equals(BookingStatus.ATTENDED)) {
							averageRatingSum = averageRatingSum + booking.getReview().getRating();
							totalCustomersAttended++;
						}
						if (!booking.getBookingStatus().equals(BookingStatus.ATTENDED)
								&& !booking.getBookingStatus().equals(BookingStatus.CANCELLED)) {
							totalCustomersBooked++;
						}
					}
				}
			}
			
			System.out.println(" Fitness Class: " + fitnessClass.getName() + "; " + " Total_Customers_Attended: "
					+ totalCustomersAttended + ";" + " Total_Customers_Booked: " + totalCustomersBooked + ";"
					+ " Average_Rating_Of_Customers_Attended: "
					+ (averageRatingSum == 0 ? 0 : averageRatingSum.doubleValue() / totalCustomersAttended));
		}
	}

	/**
	 * End flow.
	 *
	 * @param input the input
	 * @param fitnessClassList the fitness class list
	 * @param aCustomers the a customers
	 */
	private void endFlow(Scanner input, List<FitnessClass> fitnessClassList, List<Customer> aCustomers) {
		System.out.println("To go back to main menu (press b)");
		System.out.println("Press e to exit");
		boolean isFlowLoop = true;
		do {
			char enteredInput = input.next().charAt(0);
			if (enteredInput == 'b') {
				isFlowLoop = false;
				Main.mainMenuController(input, fitnessClassList, aCustomers);
			} else if (enteredInput == 'e') {
				System.exit(0);
			} else {
				System.out.println("invalid input. Please try again.");
				continue; 
			}
		} while (isFlowLoop);
	}
}