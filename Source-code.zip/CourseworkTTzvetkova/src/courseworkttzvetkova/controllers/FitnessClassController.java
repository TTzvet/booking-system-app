package courseworkttzvetkova.controllers;

import courseworkttzvetkova.Booking;
import courseworkttzvetkova.Customer;
import courseworkttzvetkova.FitnessSession;
import courseworkttzvetkova.Main;
import courseworkttzvetkova.Review;
import courseworkttzvetkova.constants.BookingStatus;
import courseworkttzvetkova.fitnessClasses.FitnessClass;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Scanner;


/**
 * The Class FitnessClassController.
 *
 * @author Teodora.Tzvetkova
 */

public class FitnessClassController {

	/**
	 * Book class.
	 *
	 * @param input the input
	 * @param aFitnessClassList the a fitness class list
	 * @param aCustomers the a customers
	 */
	public void bookClass(Scanner input, List<FitnessClass> aFitnessClassList, List<Customer> aCustomers) {
		String username = getUsername(input, aFitnessClassList, aCustomers);
		FitnessSession fitnessSession = getFitnessSession(input, "Please choose a class.", aFitnessClassList,
				aCustomers);

		if (doesUserExistsInBookings(fitnessSession.getBookingList(), username)) {
			System.out.println("User already exists. Please try again");
			fitnessSession = getFitnessSession(input, "Please choose a class.", aFitnessClassList, aCustomers);
		}
		Customer customer = getCustomer(username, aCustomers);
		customer.getFitnessSessionList().add(fitnessSession);
		fitnessSession.getBookingList().add(new Booking(customer, null, BookingStatus.BOOKED));
		System.out.println("Successfully added customer to class");
		System.out.println("Press any key to go to back to main menu");
		input.next();
		Main.mainMenuController(input, aFitnessClassList, aCustomers);
	}

	/**
	 * Change class.
	 *
	 * @param input the input
	 * @param aFitnessClassList the a fitness class list
	 * @param aCustomers the a customers
	 */
	public void changeClass(Scanner input, List<FitnessClass> aFitnessClassList, List<Customer> aCustomers) {
		String username = getUsername(input, aFitnessClassList, aCustomers);
		Customer customer = getCustomer(username, aCustomers);
		boolean validBookings = isValidBookings(customer);

		if (!validBookings) {
			System.out.println("You have no sessions booked");
			System.out.println("Press any key to go to back to main menu");
			input.next();
			Main.mainMenuController(input, aFitnessClassList, aCustomers);
		} else {
			processValidBooking(input, aFitnessClassList, aCustomers, username, customer);
		}
	}

	/**
	 * Attend class.
	 *
	 * @param input the input
	 * @param aFitnessClassList the a fitness class list
	 * @param aCustomers the a customers
	 */
	public void attendClass(Scanner input, List<FitnessClass> aFitnessClassList, List<Customer> aCustomers) {
		String username = getUsername(input, aFitnessClassList, aCustomers);
		Customer customer = getCustomer(username, aCustomers);
		boolean validBookings = isValidBookings(customer);
		
		/**
		 * Use a boolean expression to validate if a customer has booked a fitness session
		 */
		if (validBookings) {
			System.out.println("Please select the session you would like to attend");
			for (int i = 0; i < customer.getFitnessSessionList().size(); i++) {
				FitnessSession fitnessSession = customer.getFitnessSessionList().get(i);
				for (int p = 0; p < fitnessSession.getBookingList().size(); p++) {
					Booking booking = fitnessSession.getBookingList().get(p);
					if (booking.getCustomer().getUsername().equals(customer.getUsername())
							&& (booking.getBookingStatus().equals(BookingStatus.BOOKED)
									|| booking.getBookingStatus().equals(BookingStatus.CHANGED))) {
						LocalDateTime localDateTime = fitnessSession.getSessionStartDateTime();
						System.out.println("  Fitness class: " + fitnessSession.getClassName() + "; Session Date: "
								+ localDateTime.toLocalDate().toString() + "; Session Time: "
								+ localDateTime.toLocalTime().toString() + " (enter " + "'" + i + "-" + p + "'"
								+ " to select)");

					}
				}
			}
		} else {
			System.out.println("You have no sessions to attend");
			System.out.println("Press any key to go to back to main menu");
			input.next();
			Main.mainMenuController(input, aFitnessClassList, aCustomers);
		}

		String index = input.next();
		String[] sessionBookingIndexes = index.split("-");
		int sessionIndex = Integer.parseInt(sessionBookingIndexes[0]);
		int bookingIndex = Integer.parseInt(sessionBookingIndexes[1]);
		customer.getFitnessSessionList().get(sessionIndex).getBookingList().get(bookingIndex)
				.setBookingStatus(BookingStatus.ATTENDED);
		System.out.println("session marked as attended, please provide a rating score (from 1 to 5)");
		int score = input.nextInt();
		System.out.println("please leave a comment about your experience if you like");
		String comment = input.next();
		customer.getFitnessSessionList().get(sessionIndex).getBookingList().get(bookingIndex)
				.setReview(new Review(username, comment, score));
		System.out.println("thank you");
		System.out.println("Press any key to go to back to main menu");
		input.next();
		Main.mainMenuController(input, aFitnessClassList, aCustomers);
	}

	/**
	 * Checks if is valid bookings.
	 *
	 * @param aCustomer the a customer
	 * @return true, if is valid bookings
	 */
	private boolean isValidBookings(Customer aCustomer) {
		for (int i = 0; i < aCustomer.getFitnessSessionList().size(); i++) {
			FitnessSession fitnessSession = aCustomer.getFitnessSessionList().get(i);
			for (Booking booking : fitnessSession.getBookingList()) {
				if (booking.getCustomer().getUsername().equals(aCustomer.getUsername())
						&& (booking.getBookingStatus().equals(BookingStatus.BOOKED)
								|| booking.getBookingStatus().equals(BookingStatus.CHANGED))) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Process valid booking.
	 *
	 * @param input the input
	 * @param aFitnessClassList the a fitness class list
	 * @param aCustomers the a customers
	 * @param aUsername the a username
	 * @param aCustomer the a customer
	 */
	private void processValidBooking(Scanner input, List<FitnessClass> aFitnessClassList, List<Customer> aCustomers,
			String aUsername, Customer aCustomer) {
		System.out.println("Please select the session you would like to change or cancel");
		for (int i = 0; i < aCustomer.getFitnessSessionList().size(); i++) {
			FitnessSession fitnessSession = aCustomer.getFitnessSessionList().get(i);
			for (int p = 0; p < fitnessSession.getBookingList().size(); p++) {
				Booking booking = fitnessSession.getBookingList().get(p);
				if (booking.getCustomer().getUsername().equals(aCustomer.getUsername())
						&& (booking.getBookingStatus().equals(BookingStatus.BOOKED)
								|| booking.getBookingStatus().equals(BookingStatus.CHANGED))) {
					LocalDateTime localDateTime = fitnessSession.getSessionStartDateTime();
					System.out.println("  Fitness class: " + fitnessSession.getClassName() + "; Session Date: "
							+ localDateTime.toLocalDate().toString() + "; Session Time: "
							+ localDateTime.toLocalTime().toString() + " (enter " + "'" + i + "-" + p + "'"
							+ " to select)");

				}
			}
		}

		String index = input.next();
		System.out.println("press c to change or press n to cancel booking");
		String sessionOperation = input.next();
		String[] sessionBookingIndexes = index.split("-");
		int sessionIndex = Integer.parseInt(sessionBookingIndexes[0]);
		int bookingIndex = Integer.parseInt(sessionBookingIndexes[1]);
		aCustomer.getFitnessSessionList().get(sessionIndex).getBookingList().get(bookingIndex)
				.setBookingStatus(BookingStatus.CANCELLED);
		
		/**
		 * To cancel booking
		 */
		
		if (sessionOperation.equals("n")) {
			System.out.println("successfully cancelled booking");
			System.out.println("Press any key to go to back to main menu");
			input.next();
			Main.mainMenuController(input, aFitnessClassList, aCustomers);
		}
		
		/**
		 * To change booking
		 */
		
		else if (sessionOperation.equals("c")) {
			FitnessSession fitnessSession = getFitnessSession(input, "Please choose a new class.", aFitnessClassList,
					aCustomers);

			if (doesUserExistsInBookings(fitnessSession.getBookingList(), aUsername)) {
				System.out.println("User already exists. Please try again");
				fitnessSession = getFitnessSession(input, "Please choose a new class.", aFitnessClassList, aCustomers);
			}
			aCustomer.getFitnessSessionList().add(fitnessSession);
			fitnessSession.getBookingList().add(new Booking(aCustomer, null, BookingStatus.CHANGED));
			System.out.println("Successfully added customer to class");
			System.out.println("Press any key to go to back to main menu");
			input.next();
			Main.mainMenuController(input, aFitnessClassList, aCustomers);
		} else {
			System.out.println("invalid input");
			System.out.println("Press any key to go to back to main menu");
			input.next();
			Main.mainMenuController(input, aFitnessClassList, aCustomers);
		}
	}

	/**
	 * Gets the username.
	 *
	 * @param input the input
	 * @param aFitnessClassList the a fitness class list
	 * @param aCustomers the a customers
	 * @return the username
	 */
	private String getUsername(Scanner input, List<FitnessClass> aFitnessClassList, List<Customer> aCustomers) {
		System.out.println("Please enter customer's username");
		String username = input.next();
		if (!alreadyExists(username, aCustomers)) {
			System.out.println("username does not exist. Please create a new customer");
			System.out.println("Press any key to go to back to main menu");
			input.next();
			Main.mainMenuController(input, aFitnessClassList, aCustomers);
		}
		return username;
	}

	/**
	 * Gets the customer.
	 *
	 * @param username the username
	 * @param aCustomers the a customers
	 * @return the customer
	 */
	private Customer getCustomer(String username, List<Customer> aCustomers) {
		for (Customer customer : aCustomers) {
			if (customer.getUsername().equals(username)) {
				return customer;
			}
		}
		return null;
	}

	/**
	 * Gets the fitness session.
	 *
	 * @param input the input
	 * @param textInput the text input
	 * @param aFitnessClassList the a fitness class list
	 * @param aCustomers the a customers
	 * @return the fitness session
	 */
	private FitnessSession getFitnessSession(Scanner input, String textInput, List<FitnessClass> aFitnessClassList,
			List<Customer> aCustomers) {
		int classIndex = getClassIndex(input, textInput, aFitnessClassList);
		int sessionIndex = getSessionIndex(input, aFitnessClassList, classIndex);
		if (sessionIndex == -1) {
			System.out.println("all sessions are full. Please start again.");
			Main.mainMenuController(input, aFitnessClassList, aCustomers);
			return null;
		}
		return aFitnessClassList.get(classIndex).getFitnessSessions().get(sessionIndex);
	}

	/**
	 * Gets the session index.
	 *
	 * @param input the input
	 * @param aFitnessClassList the a fitness class list
	 * @param aClassIndex the a class index
	 * @return the session index
	 */
	
	/**
	 * This method checks if there are available bookings (i.e. less than 20)
	*/
	 
	private int getSessionIndex(Scanner input, List<FitnessClass> aFitnessClassList, int aClassIndex) {
		boolean availableSessions = false;
		for (int p = 0; p < aFitnessClassList.get(aClassIndex).getFitnessSessions().size(); p++) {
			int validBookings = getValidBookings(
					aFitnessClassList.get(aClassIndex).getFitnessSessions().get(p).getBookingList());
			if (validBookings < 20) {
				LocalDateTime localDateTime = aFitnessClassList.get(aClassIndex).getFitnessSessions().get(p)
						.getSessionStartDateTime();
				System.out.println("Session Date: " + localDateTime.toLocalDate().toString() + "; Session Time: "
						+ localDateTime.toLocalTime().toString() + " (enter " + p + " to select)");
				availableSessions = true;
			}
		}
		if (!availableSessions) {
			return -1;
		}
		return input.nextInt();
	}

	/**
	 * Gets the class index.
	 *
	 * @param input the input
	 * @param textInput the text input
	 * @param aFitnessClassList the a fitness class list
	 * @return the class index
	 */
	private int getClassIndex(Scanner input, String textInput, List<FitnessClass> aFitnessClassList) {
		System.out.println(textInput);
		for (int i = 0; i < aFitnessClassList.size(); i++) {
			System.out.println(aFitnessClassList.get(i).getName() + " (enter " + i + " to select)");
		}

		return input.nextInt();
	}

	/**
	 * Does user exists in bookings.
	 *
	 * @param aBookings the a bookings
	 * @param username the username
	 * @return true, if successful
	 */
	private boolean doesUserExistsInBookings(List<Booking> aBookings, String username) {
		for (Booking booking : aBookings) {
			if (booking.getCustomer().getUsername().equals(username)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Gets the valid bookings.
	 *
	 * @param aBookings the a bookings
	 * @return the valid bookings
	 */
	
	/**
	 * This method checks the amount of valid bookings in this class/session, which aren't cancelled.
	 */
		
	private int getValidBookings(List<Booking> aBookings) {
		int validBookings = 0;
		for (Booking booking : aBookings) {
			if (!booking.getBookingStatus().equals(BookingStatus.CANCELLED)) {
				validBookings++;
			}
		}
		return validBookings;
	}

	/**
	 * Already exists.
	 *
	 * @param username the username
	 * @param aCustomers the a customers
	 * @return true, if successful
	 */
	
	/**
	 * To validate if customer's username already exists in the database (InitialiseData)
	*/
	private boolean alreadyExists(String username, List<Customer> aCustomers) {
		for (Customer customer : aCustomers) {
			if (customer.getUsername().equals(username)) {
				return true;
			}
		}
		return false;
	}
}
