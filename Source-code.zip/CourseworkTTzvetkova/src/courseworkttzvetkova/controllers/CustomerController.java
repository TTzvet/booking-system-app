package courseworkttzvetkova.controllers;

import courseworkttzvetkova.Customer;
import courseworkttzvetkova.Main;
import courseworkttzvetkova.fitnessClasses.FitnessClass;
import java.util.List;
import java.util.Scanner;


/**
 * The Class CustomerController.
 *
 * @author Teodora.Tzvetkova
 */

public class CustomerController {

	/**
	 * Adds the new customer.
	 *
	 * @param input the input
	 * @param aFitnessClasses the a fitness classes
	 * @param aCustomerList the a customer list
	 */
	public void addNewCustomer(Scanner input, List<FitnessClass> aFitnessClasses, List<Customer> aCustomerList) {
		System.out.println("Please enter username");
		String username = input.next();
		
		/**
		 * Validation of username
		 */
		
		if (alreadyExists(username, aCustomerList)) {
			System.out.println("user already exists. please enter a new username");
			addNewCustomer(input, aFitnessClasses, aCustomerList);
		}
		
		System.out.println("Please enter name");
		String name = input.next();
		System.out.println("Please enter age");
		int age = input.nextInt();
		Customer customer = new Customer(username, age, name);
		aCustomerList.add(customer);
		System.out.println(
				"User created with the following data: username: " + username + "; name: " + name + "; age: " + age);
		System.out.println("Press any key to go to back to main menu");
		input.next();
		Main.mainMenuController(input, aFitnessClasses, aCustomerList);
	}

	/**
	 * Already exists.
	 *
	 * @param username the username
	 * @param aCustomers the a customers
	 * @return true, if successful
	 */
	
	/**
	 * Checks if username already exists
	 */
	
	private boolean alreadyExists(String username, List<Customer> aCustomers) {
		for (Customer customer : aCustomers) {
			if (customer.getUsername().equals(username)) {
				return true;
			}
		}
		return false;
	}
}