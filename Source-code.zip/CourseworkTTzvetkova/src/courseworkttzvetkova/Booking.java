
package courseworkttzvetkova;


/**
 * The Class Booking.
 *
 * @author Teodora.Tzvetkova
 */
public class Booking {

	/** The m customer. */
	private Customer mCustomer;
	
	/** The m review. */
	private Review mReview;
	
	/** The booking status. */
	private String bookingStatus;

	
	/**
	 * Instantiates a new booking.
	 *
	 * @param aCustomer the a customer
	 * @param aReview the a review
	 * @param aBookingStatus the a booking status
	 */
	public Booking(Customer aCustomer, Review aReview, String aBookingStatus) {
		mCustomer = aCustomer;
		bookingStatus = aBookingStatus;
		mReview = aReview;
	}

	
	/**
	 * Gets the customer.
	 *
	 * @return the customer
	 */
	public Customer getCustomer() {
		return mCustomer;
	}

	
	/**
	 * Sets the customer.
	 *
	 * @param aCustomer the new customer
	 */
	public void setCustomer(Customer aCustomer) {
		mCustomer = aCustomer;
	}

	
	/**
	 * Gets the booking status.
	 *
	 * @return the booking status
	 */
	public String getBookingStatus() {
		return bookingStatus;
	}

	
	/**
	 * Sets the booking status.
	 *
	 * @param aBookingStatus the new booking status
	 */
	public void setBookingStatus(String aBookingStatus) {
		bookingStatus = aBookingStatus;
	}

	
	/**
	 * Gets the review.
	 *
	 * @return the review
	 */
	public Review getReview() {
		return mReview;
	}

	
	/**
	 * Sets the review.
	 *
	 * @param aReview the new review
	 */
	public void setReview(Review aReview) {
		mReview = aReview;
	}
}